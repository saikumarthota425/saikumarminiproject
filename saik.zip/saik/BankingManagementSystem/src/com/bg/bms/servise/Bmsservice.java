package com.bg.bms.servise;

import java.time.LocalDate;
import java.util.List;

import com.cg.bms.expection.BmsExpection;
import com.cg.bms.model.Customers;
import com.cg.bms.model.Transactions;

public interface Bmsservice {

	boolean validateUser(int userId, String password) throws BmsExpection;
	boolean validatefields(Customers customers);

	Long insertingCustomerData(Customers customers) throws BmsExpection;
	List<Transactions> dailyTransactions(LocalDate date) throws BmsExpection;
	List<Transactions> selectingtranscationyear(int year) throws BmsExpection;
	List<Transactions> selectingtranscationmonth(int month1, int year1) throws BmsExpection;

	

}
