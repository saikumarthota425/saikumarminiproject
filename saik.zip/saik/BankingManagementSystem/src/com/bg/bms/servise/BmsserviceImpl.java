package com.bg.bms.servise;

import java.time.LocalDate;
import java.util.List;

import com.cg.bms.dao.Bmsdao;
import com.cg.bms.dao.BmsdaoImpl;
import com.cg.bms.expection.BmsExpection;
import com.cg.bms.model.Customers;
import com.cg.bms.model.Transactions;

public class BmsserviceImpl implements Bmsservice {
	
	Bmsdao bmsdao = new BmsdaoImpl();

	@Override
	public boolean validateUser(int userId, String password) throws BmsExpection {
	
		return bmsdao.validateUser(userId,password);
	}
	@Override
	public boolean validatefields(Customers customers) {
		boolean result = false;
		return result;
	}

	@Override
	public Long insertingCustomerData(Customers customers) throws BmsExpection{
		return bmsdao.insertingCustomerData(customers);
	}
	@Override
	public List<Transactions> dailyTransactions(LocalDate date) throws BmsExpection {
		
		return bmsdao.selectingTransactiondDaily(date);
	}
	@Override
	public List<Transactions> selectingtranscationyear(int year) throws BmsExpection {
		// TODO Auto-generated method stub
		return bmsdao.selectingtranscationyear(year);
	}
	@Override
	public List<Transactions> selectingtranscationmonth(int month, int year1) throws BmsExpection {
		// TODO Auto-generated method stub
		return bmsdao.selectingtranscationmonth( month,year1);
	}

	

}
