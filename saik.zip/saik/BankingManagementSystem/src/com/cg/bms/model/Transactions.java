package com.cg.bms.model;

import java.time.LocalDate;

public class Transactions {
	
	private Long transactionId;
	private String transactionDescriptiong;
	private LocalDate dateOfTransfer;
	private String transtionType;
	private int transactionAmount;
	private Long accountId;
	
	public Transactions() {
		// TODO Auto-generated constructor stub
	}

	public Transactions(Long transactionId, String transactionDescriptiong, LocalDate dateOfTransfer,
			String transtionType, int transactionAmount, Long accountId) {
		super();
		this.transactionId = transactionId;
		this.transactionDescriptiong = transactionDescriptiong;
		this.dateOfTransfer = dateOfTransfer;
		this.transtionType = transtionType;
		this.transactionAmount = transactionAmount;
		this.accountId = accountId;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDescriptiong() {
		return transactionDescriptiong;
	}

	public void setTransactionDescriptiong(String transactionDescriptiong) {
		this.transactionDescriptiong = transactionDescriptiong;
	}

	public LocalDate getDateOfTransfer() {
		return dateOfTransfer;
	}

	public void setDateOfTransfer(LocalDate dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}

	public String getTranstionType() {
		return transtionType;
	}

	public void setTranstionType(String transtionType) {
		this.transtionType = transtionType;
	}

	public int getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(int transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	
	
	

}
