package com.cg.bms.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.bms.expection.BmsExpection;
import com.cg.bms.model.Customers;
import com.cg.bms.model.Transactions;

public interface Bmsdao {

	boolean validateUser(int userId, String password) throws BmsExpection;

	Long insertingCustomerData(Customers customers) throws BmsExpection;

	List<Transactions> selectingTransactiondDaily(LocalDate date) throws BmsExpection;

	List<Transactions> selectingtranscationyear(int year) throws BmsExpection;

	List<Transactions> selectingtranscationmonth(int month, int year1) throws BmsExpection;

}
