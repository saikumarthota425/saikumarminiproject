package com.cg.bms.dao;

public interface QueryMapper {
	String valiadateUser = "SELECT * from User_Table";
	
	String insertingCustomerData = "insert into customer values(accountid_sequence.Nextval,?,?,?,?)";
	
	String insertingintoaccountmaster = "insert into account_master values(?,?,?,sysdate)";
	
	
	
	String gettingId = "Select accountid_sequence.CURRVAL from dual";
	
	String selectingTranscationsDetails = "select* from transaction where dateoftransaction =?";
	
	String getingtranscationyear = "select* from transaction where extract(year from dateoftransaction) = ?";
	
	String gettingtransactionmonth = "select* from transaction where extract(month from dateoftransaction) = ? and extract(year from dateoftransaction) =?";

}
