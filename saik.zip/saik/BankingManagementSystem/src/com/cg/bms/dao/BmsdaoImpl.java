package com.cg.bms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.bms.expection.BmsExpection;
import com.cg.bms.model.Customers;
import com.cg.bms.model.Transactions;
import com.cg.bms.utility.JdbcUtility;

public class BmsdaoImpl implements Bmsdao {

	Connection connection = null;
	PreparedStatement preparestatement = null;
	ResultSet resultset = null;
	ResultSet resultset1 = null;

	@Override
	public boolean validateUser(int userId, String password) throws BmsExpection {

		connection = JdbcUtility.getConnection();
		boolean result = false;
		try {
			preparestatement = connection.prepareStatement(QueryMapper.valiadateUser);
			resultset = preparestatement.executeQuery();

			while (resultset.next()) {
				int id = resultset.getInt("USER_ID");
				String name = resultset.getString("LOGIN_PASSWORD");
				if (id == userId && name.equals(password)) {
					result = true;

				}

			}

		} catch (SQLException e) {

			throw new BmsExpection("no connection");
		} finally {
			try {
				connection.close();

			} catch (SQLException e) {
				throw new BmsExpection("connection not closed");
			}
			try {
				preparestatement.close();
			} catch (SQLException e) {
				throw new BmsExpection("preparesatement not closed");

			}
			try {
				resultset.close();
			} catch (SQLException e) {
				throw new BmsExpection("resultset not closed");
			}
		}

		return result;
	}

	@Override
	public Long insertingCustomerData(Customers customers) throws BmsExpection {
		connection = JdbcUtility.getConnection();
		Long result = (long) 0;
		try {
			preparestatement = connection.prepareStatement(QueryMapper.insertingCustomerData);
			preparestatement.setString(1, customers.getCustomerName());
			preparestatement.setString(2, customers.getEmail());
			preparestatement.setString(3, customers.getAddress());
			preparestatement.setString(4, customers.getPancard());
			preparestatement.executeUpdate();

			preparestatement = connection.prepareStatement(QueryMapper.gettingId);
			resultset = preparestatement.executeQuery();
			resultset.next();
			result = resultset.getLong(1);
			
			preparestatement = connection.prepareStatement(QueryMapper.insertingintoaccountmaster);
			preparestatement.setLong(1,result);
			preparestatement.setString(2,customers.getAccountType());
			preparestatement.setLong(3,customers.getAccountBalance());
			preparestatement.executeUpdate();
			
			
			
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return result;
	}

	@Override
	public List<Transactions> selectingTransactiondDaily(LocalDate date) throws BmsExpection {
		List<Transactions> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			preparestatement = connection.prepareStatement(QueryMapper.selectingTranscationsDetails);
			Date date1 = Date.valueOf(date);
			System.out.println(date1);
			preparestatement.setDate(1, date1);
			resultset = preparestatement.executeQuery();

			while (resultset.next()) {

				Long id = resultset.getLong("transactio_id");
				String desc = resultset.getString("TRAN_DESCRIPTION");
				LocalDate dates = resultset.getDate("DATEOFTRANSACTION").toLocalDate();
				int amount = resultset.getInt("TRANAMOUNT");
				String transtype = resultset.getString("TRANSACTION_TYPE");
				Long accountid = resultset.getLong("ACCOUNT_NO");

				Transactions transactions = new Transactions();
				transactions.setTransactionId(id);
				transactions.setTransactionDescriptiong(desc);
				transactions.setDateOfTransfer(dates);
				transactions.setTransactionAmount(amount);
				transactions.setTranstionType(transtype);
				transactions.setAccountId(accountid);

				list.add(transactions);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<Transactions> selectingtranscationyear(int year) throws BmsExpection {
		List<Transactions> list1 = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			preparestatement = connection.prepareStatement(QueryMapper.getingtranscationyear);
			preparestatement.setInt(1,year);
			resultset = preparestatement.executeQuery();
			
			while (resultset.next()) {
				
				
				Long id = resultset.getLong("transactio_id");
				String desc = resultset.getString("TRAN_DESCRIPTION");
				LocalDate dates = resultset.getDate("DATEOFTRANSACTION").toLocalDate();
				int amount = resultset.getInt("TRANAMOUNT");
				String transtype = resultset.getString("TRANSACTION_TYPE");
				Long accountid = resultset.getLong("ACCOUNT_NO");

				Transactions transactions = new Transactions();
				transactions.setTransactionId(id);
				transactions.setTransactionDescriptiong(desc);
				transactions.setDateOfTransfer(dates);
				transactions.setTransactionAmount(amount);
				transactions.setTranstionType(transtype);
				transactions.setAccountId(accountid);

				list1.add(transactions);
				
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
		return list1;
	}

	@Override
	public List<Transactions> selectingtranscationmonth(int month, int year1) throws BmsExpection {
		List<Transactions> list1 = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			preparestatement = connection.prepareStatement(QueryMapper.gettingtransactionmonth);
			preparestatement.setInt(1,month);
			preparestatement.setInt(2,year1);
			resultset = preparestatement.executeQuery();
           while (resultset.next()) {
				
				
				Long id = resultset.getLong("transactio_id");
				String desc = resultset.getString("TRAN_DESCRIPTION");
				LocalDate dates = resultset.getDate("DATEOFTRANSACTION").toLocalDate();
				int amount = resultset.getInt("TRANAMOUNT");
				String transtype = resultset.getString("TRANSACTION_TYPE");
				Long accountid = resultset.getLong("ACCOUNT_NO");

				Transactions transactions = new Transactions();
				transactions.setTransactionId(id);
				transactions.setTransactionDescriptiong(desc);
				transactions.setDateOfTransfer(dates);
				transactions.setTransactionAmount(amount);
				transactions.setTranstionType(transtype);
				transactions.setAccountId(accountid);

				list1.add(transactions);
				
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return list1;
	}

}
