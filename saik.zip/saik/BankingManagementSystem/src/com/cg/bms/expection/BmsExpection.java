package com.cg.bms.expection;

public class BmsExpection extends Exception {
	
  public BmsExpection(String message) {
	  super(message);
	
}
}
