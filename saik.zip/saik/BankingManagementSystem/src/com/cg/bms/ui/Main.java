package com.cg.bms.ui;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.bg.bms.servise.Bmsservice;
import com.bg.bms.servise.BmsserviceImpl;
import com.cg.bms.expection.BmsExpection;
import com.cg.bms.model.Customers;
import com.cg.bms.model.Transactions;
import com.cg.bms.model.Users;

public class Main {
	static Scanner scanner = null;
	static boolean flag = false;

	public static void main(String[] args) throws BmsExpection {
		System.out.println("*******Banking Management System********");
		DateTimeFormatter dateTimeFormatter =null;
		LocalDate date=null;
		do {
			scanner = new Scanner(System.in);

			System.out.println("Enter userid");
	try {
			int userId = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter password");
			String loginPassword = scanner.nextLine();

			Users users = new Users();
			users.setUserId(userId);
			users.setPassword(loginPassword);

			Bmsservice bmsservice = new BmsserviceImpl();
			boolean result = bmsservice.validateUser(users.getUserId(), users.getPassword());

			if (result == true) {
				flag = true;
				System.out.println("1. create account");
				System.out.println("2. view transations");
				System.out.println("please select choice");
				
				int choice = scanner.nextInt();
				
				switch (choice) {
				case 1:
					/* To display to customer for creating account */
					Customers customers = new Customers();

					System.out.println("Enter your name");
					String name = scanner.nextLine();
					scanner.nextLine();
					System.out.println("Enter your email");
					String email = scanner.nextLine();
					System.out.println("enter the address");
					String address = scanner.nextLine();
					System.out.println("enter pancard");
					String pancard = scanner.nextLine();
					System.out.println("enter your accountBalance");
					Long accountBalance = scanner.nextLong();
					if (accountBalance < 500) {
						System.err.println("account balance should be greater than 500");
						System.out.println("please enter account balalnce again");
						Long accountbalance = scanner.nextLong();
					}
					scanner.nextLine();
					System.out.println("enter your accounttype");
					String accountType = scanner.nextLine();

					customers.setCustomerName(name);
					customers.setEmail(email);
					customers.setAddress(address);
					customers.setPancard(pancard);
					customers.setAccountBalance(accountBalance);
					customers.setAccountType(accountType);
					boolean validation = bmsservice.validatefields(customers);
					Long id = bmsservice.insertingCustomerData(customers);
					System.out.println(id);

					break;
				case 2:

					int choice2 = 0;

					System.out.println("1.Daily tranastions");
					System.out.println("2.yearly transtions");
					System.out.println("3.montly transaction");
					
					System.out.println("select your choice");
					choice2 = scanner.nextInt();

					switch (choice2) {
					case 1:
						scanner.nextLine();
						System.out.println("enter the datein dd-mm-yyyy");
						String string = scanner.nextLine();
						 dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
						date = LocalDate.parse(string,dateTimeFormatter);
						
						List<Transactions> list = bmsservice.dailyTransactions(date);
						for (Transactions transactions2 : list) {

							System.out.println(transactions2.getAccountId()+"    "+
							                   transactions2.getTransactionId()+"   "
									            +transactions2.getTransactionAmount()+"   "
									            +transactions2.getTransactionDescriptiong()+"   "
									            +transactions2.getTranstionType()+"   "
									           +transactions2.getDateOfTransfer());

						}
						break;
					case 2:
						     System.out.println("Enter the year to view transcations");
						     int year = scanner.nextInt();
						     List<Transactions> list2 = bmsservice.selectingtranscationyear(year);
						     
						     for (Transactions transactions2 : list2) {

									System.out.println(transactions2.getAccountId()+"    "+
									                   transactions2.getTransactionId()+"   "
											            +transactions2.getTransactionAmount()+"   "
											            +transactions2.getTransactionDescriptiong()+"   "
											            +transactions2.getTranstionType()+"   "
											           +transactions2.getDateOfTransfer());

								}
						
                        break;
                        
					case 3:
						  scanner.nextLine();
						  System.out.println("enter the month to view the transactions in this format JAN only");
						  int month1 = scanner.nextInt();
						  System.out.println("please enter which year you want");
						  int year1 = scanner.nextInt();
						  List<Transactions> list3 = bmsservice.selectingtranscationmonth(month1,year1);
						
						
						  
						  for (Transactions transactions2 : list3) {

								System.out.println(transactions2.getAccountId()+"    "+
								                   transactions2.getTransactionId()+"   "
										            +transactions2.getTransactionAmount()+"   "
										            +transactions2.getTransactionDescriptiong()+"   "
										            +transactions2.getTranstionType()+"   "
										           +transactions2.getDateOfTransfer());

							}
						
						break;
					default:
						break;
					}

					break;

				default:
					break;
				}

			} else {
				System.err.println("please enter valid username and password");
			}
			
	         }catch(InputMismatchException e) {
	     	  System.err.println("enter only digits");
		   flag = false;
		  
		
	 }

		} while (!flag);
	}
}
